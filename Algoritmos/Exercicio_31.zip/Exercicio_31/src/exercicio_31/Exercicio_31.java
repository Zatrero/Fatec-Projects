package exercicio_31;

/**
 *
 * @author Lucas Neves GTI
 */
public class Exercicio_31 {

   
    public static void main(String[] args) {
        double m;
        System.out.println("Calcula a média entre 6, 7 e 8");
                
        m = ((6 + 7 + 8) /3.0);
        
        System.out.println("A média é: " + m);
                
    }
    
}
